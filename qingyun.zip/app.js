const Koa = require('koa');
// 注意require('koa-router')返回的是函数:
// const router = require('koa-router')();
const bodyparser = require('koa-bodyparser');
const app = new Koa();
const controllers = require('./controllers')
const logger = require('koa-logger')
const server = require('koa-static')
const path = require('path')

const handler = async (ctx, next) => {
    try {
        await next();
    } catch (err) {
        ctx.response.status = err.statusCode || err.status || 500;
        ctx.response.body = {
            message: err.message
        };
    }
};

app.use(handler); // 处理错误
app.use(logger()) // 打印日志

// 跨域设置
// app.use(async (ctx, next) => {
//     ctx.set("Access-Control-Allow-Origin", "*");
//     await next();
// })

app.use(server(path.join(__dirname))) // 加载静态资源

app.use(bodyparser()); // 解析post 内容
// add router middleware:
// 别忘了加
app.use(controllers())

app.listen(3000)
console.log('ap start at port 3000')